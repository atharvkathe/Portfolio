package com.StudentAdmission;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentAdmissionApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentAdmissionApplication.class, args);
	}
}
