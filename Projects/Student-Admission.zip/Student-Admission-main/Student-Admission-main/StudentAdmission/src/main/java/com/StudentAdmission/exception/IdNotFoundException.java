package com.StudentAdmission.exception;

public class IdNotFoundException extends RuntimeException{

	private static final long serialVersionUID = -5740323993053395302L;

	public IdNotFoundException(String msg) {
		super(msg);
		
	}
	
	
}
